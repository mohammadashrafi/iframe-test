import './App.css'

function App() {


  return (
    <>
     <h1 className="text-3xl font-bold underline text-green-900">
      Hello world!
    </h1>
    </>
  )
}

export default App
